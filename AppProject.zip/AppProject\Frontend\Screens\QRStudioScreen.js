import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ScrollView } from 'react-native';
import { QRCodeService } from '../../Backend/Services/QRCodeService';

const QRStudioScreen = () => {
  const [input, setInput] = useState('');
  const [qrUrl, setQrUrl] = useState(null);

  const handleGenerate = () => {
    if (!input.trim()) return;
    const url = QRCodeService.generate(input);
    setQrUrl(url);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>QR Studio</Text>
      <Text style={styles.subtitle}>Generate beautiful QR codes</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Enter URL or text..."
        placeholderTextColor="#6b6b80"
        value={input}
        onChangeText={setInput}
      />

      <TouchableOpacity style={[styles.button, { backgroundColor: '#00d4ff' }]} onPress={handleGenerate}>
        <Text style={styles.buttonText}>Generate QR Code</Text>
      </TouchableOpacity>

      {qrUrl && (
        <View style={styles.resultContainer}>
          <Image source={{ uri: qrUrl }} style={styles.resultImage} resizeMode="contain" />
          <Text style={styles.resultSub}>{input}</Text>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  content: { padding: 20 },
  title: { color: '#e8e8f0', fontSize: 24, fontWeight: '800' },
  subtitle: { color: '#6b6b80', fontSize: 14, marginBottom: 20 },
  input: { backgroundColor: '#1a1a26', color: '#FFF', borderRadius: 10, padding: 15, marginBottom: 20 },
  button: { padding: 15, borderRadius: 10, alignItems: 'center' },
  buttonText: { color: '#FFF', fontWeight: 'bold', fontSize: 16 },
  resultContainer: { marginTop: 30, alignItems: 'center', padding: 20, backgroundColor: '#FFF', borderRadius: 15 },
  resultImage: { width: 200, height: 200 },
  resultSub: { marginTop: 15, color: '#000', fontSize: 12, textAlign: 'center' },
});

export default QRStudioScreen;
