import { colors } from './colors';

export const globalStyles = {
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
};
