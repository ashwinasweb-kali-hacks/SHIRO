import { Alert, ToastAndroid, Platform } from 'react-native';

export const NotificationService = {
  alert: (title, message) => {
    Alert.alert(title, message);
  },

  notify: (message) => {
    if (Platform.OS === 'android') {
      ToastAndroid.show(message, ToastAndroid.SHORT);
    } else {
      console.log('Notification:', message);
    }
  },

  error: (message) => {
    Alert.alert('Error', message, [{ text: 'OK' }]);
    console.error('App Error:', message);
  }
};
