export const Validation = {
  isEmail: (email) => {
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
  },
  
  isStrongPassword: (password) => {
    // Min 8 chars, at least one letter and one number
    return password.length >= 8 && /[A-Za-z]/.test(password) && /\d/.test(password);
  },

  isEmpty: (str) => {
    return !str || str.trim().length === 0;
  },

  isUrl: (url) => {
    try {
      new URL(url);
      return true;
    } catch (_) {
      return false;
    }
  }
};
