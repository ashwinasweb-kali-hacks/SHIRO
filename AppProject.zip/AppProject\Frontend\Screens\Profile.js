import React, { useContext } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { AuthContext } from '../../Context/AuthContext';

const ProfileScreen = () => {
  const { user } = useContext(AuthContext);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>A</Text>
        </View>
        <Text style={styles.name}>Ashwin AS</Text>
        <Text style={styles.sub}>Chinmaya Vidyalaya</Text>
      </View>

      <View style={styles.infoSection}>
        <Text style={styles.label}>Email</Text>
        <Text style={styles.value}>ashwin@example.com</Text>
        
        <Text style={styles.label}>Account Type</Text>
        <Text style={styles.value}>Local Developer</Text>
      </View>

      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Edit Profile</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f', padding: 20 },
  header: { alignItems: 'center', marginTop: 40, marginBottom: 40 },
  avatar: { width: 100, height: 100, borderRadius: 50, backgroundColor: '#7c6aff', justifyContent: 'center', alignItems: 'center' },
  avatarText: { color: '#FFF', fontSize: 40, fontWeight: 'bold' },
  name: { color: '#FFF', fontSize: 24, fontWeight: 'bold', marginTop: 15 },
  sub: { color: '#7c6aff', fontSize: 14, marginTop: 5 },
  infoSection: { backgroundColor: '#12121a', padding: 20, borderRadius: 15, marginBottom: 30 },
  label: { color: '#6b6b80', fontSize: 12, textTransform: 'uppercase', marginBottom: 5 },
  value: { color: '#e8e8f0', fontSize: 16, marginBottom: 15 },
  button: { backgroundColor: '#1a1a26', padding: 15, borderRadius: 10, alignItems: 'center', borderWidth: 1, borderTopColor: 'rgba(255,255,255,0.05)' },
  buttonText: { color: '#e8e8f0', fontSize: 16, fontWeight: 'bold' },
});

export default ProfileScreen;
