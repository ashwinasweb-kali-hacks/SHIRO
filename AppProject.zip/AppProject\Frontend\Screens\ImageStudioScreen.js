import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ScrollView, ActivityIndicator } from 'react-native';
import { AISpaceService } from '../../Backend/Services/AISpaceService';

const ImageStudioScreen = () => {
  const [prompt, setPrompt] = useState('');
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const b64 = await AISpaceService.generateImage(prompt);
      setImage(b64);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Image Studio</Text>
      <Text style={styles.subtitle}>Generate stunning visuals locally</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Enter prompt..."
        placeholderTextColor="#6b6b80"
        value={prompt}
        onChangeText={setPrompt}
        multiline
      />

      <TouchableOpacity style={styles.button} onPress={handleGenerate} disabled={loading}>
        {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.buttonText}>Generate Image</Text>}
      </TouchableOpacity>

      {error && <Text style={styles.errorText}>{error}</Text>}

      {image && (
        <View style={styles.resultContainer}>
          <Image source={{ uri: image }} style={styles.resultImage} resizeMode="contain" />
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  content: { padding: 20 },
  title: { color: '#e8e8f0', fontSize: 24, fontWeight: '800' },
  subtitle: { color: '#6b6b80', fontSize: 14, marginBottom: 20 },
  input: { backgroundColor: '#1a1a26', color: '#FFF', borderRadius: 10, padding: 15, height: 100, textAlignVertical: 'top', marginBottom: 20 },
  button: { backgroundColor: '#7c6aff', padding: 15, borderRadius: 10, alignItems: 'center' },
  buttonText: { color: '#FFF', fontWeight: 'bold', fontSize: 16 },
  errorText: { color: '#ff4757', marginTop: 20, textAlign: 'center' },
  resultContainer: { marginTop: 30, borderRadius: 15, overflow: 'hidden', backgroundColor: '#1a1a26', elevation: 5 },
  resultImage: { width: '100%', height: 350 },
});

export default ImageStudioScreen;
