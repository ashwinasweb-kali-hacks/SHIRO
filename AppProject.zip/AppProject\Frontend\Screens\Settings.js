import React from 'react';
import { View, Text, StyleSheet, Switch, ScrollView } from 'react-native';

const SettingsScreen = () => {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Settings</Text>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Local AI</Text>
        <View style={styles.settingRow}>
          <Text style={styles.settingLabel}>Stream Responses</Text>
          <Switch value={true} />
        </View>
        <View style={styles.settingRow}>
          <Text style={styles.settingLabel}>Offline Mode Only</Text>
          <Switch value={true} />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Appearance</Text>
        <View style={styles.settingRow}>
          <Text style={styles.settingLabel}>Dark Mode</Text>
          <Switch value={true} />
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f', padding: 20 },
  title: { color: '#FFF', fontSize: 28, fontWeight: '800', marginBottom: 30 },
  section: { marginBottom: 30 },
  sectionTitle: { color: '#7c6aff', fontSize: 14, fontWeight: 'bold', textTransform: 'uppercase', marginBottom: 15, letterSpacing: 1 },
  settingRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.05)' },
  settingLabel: { color: '#e8e8f0', fontSize: 16 },
});

export default SettingsScreen;
