const DEFAULT_BACKEND = 'http://localhost:8000';

export const AISpaceService = {
  generateImage: async (prompt, steps = 12) => {
    try {
      const response = await fetch(`${DEFAULT_BACKEND}/api/generate-image`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, num_inference_steps: steps }),
      });
      const data = await response.json();
      if (!response.ok || !data.success) throw new Error(data.detail || 'Failed to generate image');
      return data.image_base64;
    } catch (error) {
      console.error('AISpace Image Error:', error);
      throw error;
    }
  },

  generateVideo: async (prompt, frames = 8, steps = 8) => {
    try {
      const response = await fetch(`${DEFAULT_BACKEND}/api/generate-video`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, num_frames: frames, num_inference_steps: steps }),
      });
      const data = await response.json();
      if (!response.ok || !data.success) throw new Error(data.detail || 'Failed to generate video');
      return data.video_base64;
    } catch (error) {
      console.error('AISpace Video Error:', error);
      throw error;
    }
  }
};
