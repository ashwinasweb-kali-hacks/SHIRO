import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import Card from '../../Components/Card';
import { colors } from '../../CSS/colors';

const HomeScreen = () => {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Welcome to Shiro AI</Text>
      <Text style={styles.subtitle}>Your local AI powerhouse</Text>
      
      <Card>
        <Text style={styles.cardTitle}>Recent Activity</Text>
        <Text style={styles.cardText}>You haven't generated any content yet. Try the Chat or Image Studio!</Text>
      </Card>

      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={styles.statValue}>0</Text>
          <Text style={styles.statLabel}>Images</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statValue}>0</Text>
          <Text style={styles.statLabel}>Videos</Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  content: { padding: 20 },
  title: { color: '#e8e8f0', fontSize: 28, fontWeight: '800', marginBottom: 5 },
  subtitle: { color: '#6b6b80', fontSize: 16, marginBottom: 30 },
  cardTitle: { color: '#7c6aff', fontSize: 18, fontWeight: 'bold', marginBottom: 10 },
  cardText: { color: '#6b6b80', fontSize: 14 },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 20 },
  statBox: { backgroundColor: '#1a1a26', padding: 20, borderRadius: 15, width: '48%', alignItems: 'center' },
  statValue: { color: '#FFF', fontSize: 24, fontWeight: 'bold' },
  statLabel: { color: '#6b6b80', fontSize: 12, marginTop: 5 },
});

export default HomeScreen;
