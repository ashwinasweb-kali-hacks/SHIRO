import React from 'react';
import { View, StyleSheet } from 'react-native';

const Card = ({ children }) => (
  <View style={styles.card}>
    {children}
  </View>
);

const styles = StyleSheet.create({
  card: {
    padding: 15,
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    elevation: 3,
  },
});

export default Card;
