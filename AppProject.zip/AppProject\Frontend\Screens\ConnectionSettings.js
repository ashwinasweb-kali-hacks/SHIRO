import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { LocalStorageService } from '../../Services/LocalStorageService';

const ConnectionSettings = () => {
  const [pcIp, setPcIp] = useState('192.168.1.100'); // Example IP

  useEffect(() => {
    const loadIp = async () => {
      const savedIp = await LocalStorageService.load('pc_ip');
      if (savedIp) setPcIp(savedIp);
    };
    loadIp();
  }, []);

  const handleSave = async () => {
    await LocalStorageService.save('pc_ip', pcIp);
    alert('Settings Saved! The app will now connect to ' + pcIp);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Mobile Connection</Text>
      <Text style={styles.subtitle}>Enter your PC's IP address to use AI models from your phone.</Text>

      <View style={styles.inputGroup}>
        <Text style={styles.label}>PC IP Address</Text>
        <TextInput
          style={styles.input}
          value={pcIp}
          onChangeText={setPcIp}
          placeholder="e.g. 192.168.1.5"
          placeholderTextColor="#6b6b80"
          keyboardType="numeric"
        />
        <Text style={styles.hint}>You can find this by running 'ipconfig' on your PC.</Text>
      </View>

      <TouchableOpacity style={styles.button} onPress={handleSave}>
        <Text style={styles.buttonText}>Save Connection</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f', padding: 20 },
  title: { color: '#FFF', fontSize: 24, fontWeight: '800', marginBottom: 10 },
  subtitle: { color: '#6b6b80', fontSize: 14, marginBottom: 30 },
  inputGroup: { marginBottom: 30 },
  label: { color: '#7c6aff', fontSize: 12, textTransform: 'uppercase', marginBottom: 10 },
  input: { backgroundColor: '#1a1a26', color: '#FFF', padding: 15, borderRadius: 10, fontSize: 18 },
  hint: { color: '#6b6b80', fontSize: 12, marginTop: 10 },
  button: { backgroundColor: '#7c6aff', padding: 18, borderRadius: 12, alignItems: 'center' },
  buttonText: { color: '#FFF', fontWeight: 'bold', fontSize: 16 }
});

export default ConnectionSettings;
