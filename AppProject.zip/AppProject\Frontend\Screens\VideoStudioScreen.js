import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { AISpaceService } from '../../Backend/Services/AISpaceService';

const VideoStudioScreen = () => {
  const [prompt, setPrompt] = useState('');
  const [video, setVideo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const b64 = await AISpaceService.generateVideo(prompt);
      setVideo(b64);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Video Studio</Text>
      <Text style={styles.subtitle}>Generate AI videos offline</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Enter prompt..."
        placeholderTextColor="#6b6b80"
        value={prompt}
        onChangeText={setPrompt}
        multiline
      />

      <TouchableOpacity style={[styles.button, { backgroundColor: '#ff4b9a' }]} onPress={handleGenerate} disabled={loading}>
        {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.buttonText}>Generate Video</Text>}
      </TouchableOpacity>

      {error && <Text style={styles.errorText}>{error}</Text>}

      {video && (
        <View style={styles.resultContainer}>
          <Text style={{ color: '#00d4ff', textAlign: 'center' }}>Video generated! (Base64 ready)</Text>
          <Text style={{ color: '#6b6b80', fontSize: 10, marginTop: 10 }}>Note: Video player requires native module on mobile.</Text>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0f' },
  content: { padding: 20 },
  title: { color: '#e8e8f0', fontSize: 24, fontWeight: '800' },
  subtitle: { color: '#6b6b80', fontSize: 14, marginBottom: 20 },
  input: { backgroundColor: '#1a1a26', color: '#FFF', borderRadius: 10, padding: 15, height: 100, textAlignVertical: 'top', marginBottom: 20 },
  button: { padding: 15, borderRadius: 10, alignItems: 'center' },
  buttonText: { color: '#FFF', fontWeight: 'bold', fontSize: 16 },
  errorText: { color: '#ff4757', marginTop: 20, textAlign: 'center' },
  resultContainer: { marginTop: 30, padding: 20, borderRadius: 15, backgroundColor: '#1a1a26' },
});

export default VideoStudioScreen;
