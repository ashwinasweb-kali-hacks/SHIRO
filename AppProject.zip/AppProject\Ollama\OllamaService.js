const DEFAULT_HOST = 'http://localhost:11434';

export const OllamaService = {
  // Generate a response for a single prompt (Basic)
  generate: async (prompt, model = 'llama3.2', images = null, stream = true, onChunk = null) => {
    try {
      const response = await fetch(`${DEFAULT_HOST}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model,
          prompt,
          stream,
          images: images // Array of base64 strings
        }),
      });

      if (!response.ok) throw new Error(`Ollama Error: ${response.statusText}`);

      return stream ? handleStream(response, 'response', onChunk) : (await response.json()).response;
    } catch (error) {
      console.error('Ollama Generate Error:', error);
      throw error;
    }
  },

  // Chat with history (Advanced)
  chat: async (messages, model = 'llama3.2', stream = true, onChunk = null) => {
    try {
      const response = await fetch(`${DEFAULT_HOST}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, messages, stream }),
      });

      if (!response.ok) throw new Error(`Ollama Chat Error: ${response.statusText}`);

      return stream ? handleStream(response, 'message', onChunk) : (await response.json()).message;
    } catch (error) {
      console.error('Ollama Chat Error:', error);
      throw error;
    }
  },

  listModels: async () => {
    try {
      const response = await fetch(`${DEFAULT_HOST}/api/tags`);
      const data = await response.json();
      return data.models || [];
    } catch (error) {
      console.error('Error listing Ollama models:', error);
      return [];
    }
  },

  pullModel: async (name, onProgress = null) => {
    try {
      const response = await fetch(`${DEFAULT_HOST}/api/pull`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      return handleStream(response, 'status', onProgress);
    } catch (error) {
      console.error('Error pulling model:', error);
      throw error;
    }
  },

  deleteModel: async (name) => {
    try {
      await fetch(`${DEFAULT_HOST}/api/delete`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      return true;
    } catch (error) {
      console.error('Error deleting model:', error);
      return false;
    }
  }
};

// Helper to handle streaming responses
async function handleStream(response, key, callback) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let fullContent = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value, { stream: true });
    const lines = chunk.split('\n');

    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const json = JSON.parse(line);
        const fragment = key === 'message' ? json.message?.content : json[key];
        if (fragment) {
          fullContent += fragment;
          if (callback) callback(fullContent, json);
        }
      } catch (e) {
        // Ignore parse errors from partial chunks
      }
    }
  }
  return fullContent;
}
